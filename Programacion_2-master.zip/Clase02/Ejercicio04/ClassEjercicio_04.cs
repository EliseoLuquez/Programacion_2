﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio04
{
    class ClassEjercicio_04
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 04";
        }
    }
}
