﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;

        public float Duracion
        {
            get { return duracion; }
        }

        public string NroDestino
        {
            get { return nroDestino; }
        }

        public float NroOrigen
        {
            get { return NroOrigen; }
        }

        public Centralita(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }

        public string Mostrar()
        {
            string aux = Convert.ToString(this.duracion);
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\n Duracion: {0} \nNro Destino: {1} \nNro Origen: {2}", aux, this.nroDestino,
                this.nroOrigen);

            return sb.ToString();
        }

        public int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            List<Llamada> lista = new List<Llamada>();
            lista.Add(llamada1);
            lista.Add(llamada2);
            lista.Sort();
            return 
        }
    }
}

