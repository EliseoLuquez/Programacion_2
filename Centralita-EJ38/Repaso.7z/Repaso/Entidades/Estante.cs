﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Estante
    {
        private int estanteriaUbicacion;
        private Producto[] productos;

        private Estanteria(int capacidad)
        {
            this.productos = new Producto(capacidad);
        }

        public Estanteria(int capacidad, int ubicacion): this(capacidad)
        {
            this.estanteriaUbicacion = ubicacion;
        }

        public Producto [] GetProducto()
        {
            return this.productos;
        }

        public static string MostrarEstante(Estante e)
        {
            string salidad = e.estanteriaUbicacion + " ";
            foreach(Producto producto in e.productos)
            {
                if(!(producto is null))
                {
                    salidad += " " + Producto.MostrarProducto(producto);
                }
                return salidad;
            }
        }





    }
}
