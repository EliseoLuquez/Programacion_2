﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Producto
    {
        string codigoDeBarra;
        string marca;
        float precio;

        public Producto(string codigoDeBarra, string marca, float precio)
        {
            this.marca = marca;
            this.precio = precio;
            this.codigoDeBarra = codigoDeBarra;
        }

        public string GetMarca()
        {
            return p.marca;
        }

        public float GetPrecio()
        {
            return p.precio;
        }

        public static string MostrarProducto(Producto p)
        {
            return "Codigo de barra: " + p.codigoDeBarra + "Marca: " + p.marca + "Precio: " + p.precio;
        }

        public static explicit operator string(Producto p)
        {
            return p.codigoDeBarra;
        }

        public static bool operator !=(Producto p, string marca)
        {

        }

        public static bool operator ==(Producto p, string marca)
        {
            if()
        }

        public static bool operator ==(Producto p1, Producto p2)
        {
            if ((string)p1 == (string)p2 && p1.GetMarca() == p2.GetMarca())
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            return !(p1 == p2);
        }
}
}
