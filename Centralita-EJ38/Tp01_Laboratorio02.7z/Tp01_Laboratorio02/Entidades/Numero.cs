﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
	public class Numero
	{
		private double numero;

		public Numero()
		{
			this.numero = 0;
		}

		private string SetNumero(string set)
		{
			numero = ValidarNumero(set);
			return set;
		}

		private double ValidarNumero(string strNumero)
		{
			bool esNumero = false;
			while(!esNumero)
			{
				esNumero = double.TryParse(strNumero, out double numero);
				return numero;
			}
			return numero = 0;
		}

		public string BinarioDecimal(string binario)
		{
			int numero = 0;
			for(int i = 1; i < binario.Length; i++)
			{
				if(numero < 0)
				{
					return binario = "Numero Invalido";
				}
				else
				{
					numero += int.Parse(binario[i - 1].ToString()) * (int)Math.Pow(2, binario.Length - i);
				}
			}				
			return binario;
		}

		public string DecimalBinario(double numero)
		{
			string binario = " ";
			while (numero > 0)
			{
				binario = (numero % 2).ToString() + binario;
				numero = numero / 2;
			}
			return binario;
		}

		public string Decimalbinario(string binario)
		{
			double numero = 0;
			while (numero > 0)
			{
				binario = (numero).ToString() + binario;
				numero = numero / 2;
			}
			return binario;
		}

        public static double operator +(Numero numeroUno, Numero numeroDos)
        {
            return numeroUno.numero + numeroDos.numero;
        }

        public static double operator -(Numero numeroUno, Numero numeroDos)
        {
            return numeroUno.numero - numeroDos.numero;
        }

        public static double operator /(Numero numeroUno, Numero numeroDos)
        {

            return numeroUno.numero / numeroDos.numero;
        }

        public static double operator *(Numero numeroUno, Numero numeroDos)
        {
            return numeroUno.numero * numeroDos.numero;
        }






    }
}
