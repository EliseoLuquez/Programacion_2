﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Calculadora
    {
		private static string ValidarOperador(string operador)
		{
			if (operador != "+" && operador != "-" && operador != "/" && operador != "*")
			{
				return operador = "+";
			}
			return operador;
		}

		public double Operar(Numero num1, Numero num2, string operador)
		{
            double resultado = 0;
			if (ValidarOperador(operador) == "+")
			{
                resultado = num1 + num2;
				
			}
            else if(ValidarOperador(operador) == "-")
            {
                resultado = num1 - num2;
               
            }
            else if (ValidarOperador(operador) == "*")
            {
                resultado = num1 * num2;
               
            }
            else if (ValidarOperador(operador) == "/")
            {
                resultado = num1 / num2;
               
            }
            return resultado;

        }
	}
}
