﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MiCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void BtnCerrar_Click(object sender, EventArgs e)
        {
           
        }

        private void BtnOperar_Click(object sender, EventArgs e)
        {
            
        }

        private void Limpiar()
        {
            this.txtNum1.Text = string.Empty;
            this.txtNum2.Text = string.Empty;
            this.LblRespuesta.Text = string.Empty;
        }

        private static double Operar(string numero1, string numero2, string operador)
        {
                
        }
    }
}
