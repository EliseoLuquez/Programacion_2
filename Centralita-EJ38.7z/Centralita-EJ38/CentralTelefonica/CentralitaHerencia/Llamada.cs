﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;

        /// <summary>
        /// 
        /// </summary>
        public float Duracion
        {
            get { return duracion; }
        }


        /// <summary>
        /// 
        /// </summary>
        public string NroDestino
        {
            get { return nroDestino; }
        }


        /// <summary>
        /// 
        /// </summary>
        public float NroOrigen
        {
            get { return NroOrigen; }
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="duracion"></param>
        /// <param name="nroDestino"></param>
        /// <param name="nroOrigen"></param>
        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Mostrar()
        {
            string aux = Convert.ToString(this.duracion);
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\n Duracion: {0} \nNro Destino: {1} \nNro Origen: {2}", aux, this.nroDestino,
                this.nroOrigen);

            return sb.ToString();
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="llamada1"></param>
        /// <param name="llamada2"></param>
        /// <returns></returns>
        public int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            List<Llamada> lista = new List<Llamada>();
            lista.Add(llamada1);
            lista.Add(llamada2);
            lista.Sort();
            return 
        }

        public enum TipoLlamada
        {
            Local,
            Provincial,
            Total
        }
    }
}

