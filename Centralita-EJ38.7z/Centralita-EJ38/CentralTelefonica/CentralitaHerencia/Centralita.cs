﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace CentralitaHerencia
{
    class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        private float gananciasPorLocal;

        public float GananciasPorLocal
        {
            get { return gananciasPorLocal; }
        }

        private float gananciasPorProvincia;

        public float GananciasPorProvincia
        {
            get { return gananciasPorProvincia; }
        }

        private float gananciasPorTotal;

        public float GananciasPorTotal
        {
            get { return gananciasPorTotal; }
        }

        private List<Llamada> llamadas;

        public List<Llamada> Llamadas
        {
            get { return llamadas; }
        }


        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {

        }

    }
}
