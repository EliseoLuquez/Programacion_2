﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    class Boligrafo
    {
        public const short cantidadTintaMaxima = 100;
        ConsoleColor color;
        short tinta;

        public Boligrafo(short tinta, ConsoleColor color)
        {
            this.tinta = tinta;
            this.color = color;
        }

        public ConsoleColor GetColor()
        {
            return this.color;
        }

        public short GetTinta()
        {
            return this.tinta;
        }

        public bool Pintar(int gasto, out String dibujo)
        {
            bool pintado = false;
            dibujo = " ";
            short tinta = this.GetTinta();
            int tintaTotal;
            if(this.tinta > 0)
            {
                if(this.tinta >= gasto)
                {
                    tintaTotal = tinta - gasto;
                    SetTinta((short)tintaTotal);
                  pintado = true;
                }
            }
            for(int i = 0; i < gasto; i++)
            {
                dibujo += '*';
            }
            return pintado;
        }

        public void Recargar()
        {
            this.SetTinta(cantidadTintaMaxima);
        }

        void SetTinta(short tinta)
        {
            if(tinta >= 0 && tinta <= cantidadTintaMaxima)
            {
                this.tinta = tinta;
            }
        }


        











    }
}
