﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio17
{
    class ClassEjercicio_17
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nro 17";
            int color;
            int tintaAGastar;
            bool validar;
            string dibujo;
            string aux;
           // Boligrafo boligrafo1 = new Boligrafo(100, ConsoleColor.Blue);
            //Boligrafo boligrafo2 = new Boligrafo(50, ConsoleColor.Red);
            Console.WriteLine("Ingrese Color: \n1-Azul  \n2-Rojo ");
            aux = System.Console.ReadLine();
            color = Int16.Parse(aux);
            Console.WriteLine("Ingrese Tinta a gastar: ");
            aux = System.Console.ReadLine();
            tintaAGastar = Int16.Parse(aux);
            Boligrafo boligrafo1 = new Boligrafo(100, ConsoleColor.Blue);
            switch (color)
            {
                case 1:
                    
                    break;
                case 2:
                    boligrafo1 = new Boligrafo(50, ConsoleColor.Red);
                    break;
            }
            validar = boligrafo1.Pintar(tintaAGastar, out dibujo);
            if (validar)
            {
                Console.ForegroundColor = boligrafo1.GetColor();
                Console.WriteLine(boligrafo1.GetColor());
                Console.WriteLine(dibujo);
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("La cantidad de tinta restante es: " + boligrafo1.GetTinta());
            }
            else
            {
                Console.WriteLine("No es suficiente la tinta");
                boligrafo1.Recargar();
            }


            System.Console.ReadKey();

        }
    }
}
