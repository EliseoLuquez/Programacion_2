﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Fruta
    {
        private ConsoleColor color;

        public Fruta(float valor, Gusto gusto, ConsoleColor color)
        {
            // Completar
        }
    }
}
