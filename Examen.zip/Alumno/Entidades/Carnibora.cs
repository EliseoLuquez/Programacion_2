﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Carnibora
    {
        // Tipos del enumerado: Pinzas, Pelos, Caída, Mecánicas, Combinada
        private Captura tipo;
        private int tamanio;

        public Carnibora(float valor, Gusto gusto, Captura tipo)
        {
            // Completar
        }

        public Carnibora(float valor, Gusto gusto, Captura tipo, int tamanio)
        {
            // Completar
        }
    }
}
