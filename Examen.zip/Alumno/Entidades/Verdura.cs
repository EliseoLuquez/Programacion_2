﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Verdura
    {
        // Tipos del enumerado Semilla, Raíz, Tubérculo, Bulbo, Tallo, Hoja, Inflorescencia, Rizoma
        private TipoVerdura tipo;

        public Verdura(float valor, Gusto gusto, TipoVerdura tipo)
        {
            // Completar
        }
    }
}
